import React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { leadContactSchema, type LeadContactFormData } from '../../schemas/leadSchema';
import { useFunnel } from '../../hooks/useFunnel';
import { Button } from '../common/Button';
import { Lock, ShieldCheck, ArrowRight, User, Mail, Phone, MapPin, CheckSquare, Square } from 'lucide-react';

export const ContactForm: React.FC = () => {
  const { contactInfo, saveContactAndProceed } = useFunnel();

  const {
    register,
    handleSubmit,
    setValue,
    watch,
    formState: { errors, isSubmitting },
  } = useForm<LeadContactFormData>({
    resolver: zodResolver(leadContactSchema),
    defaultValues: {
      firstName: contactInfo.firstName || '',
      lastName: contactInfo.lastName || '',
      email: contactInfo.email || '',
      phone: contactInfo.phone || '',
      zipCode: contactInfo.zipCode || '',
      consent: contactInfo.consent ?? true,
    },
    mode: 'onTouched',
  });

  const consentChecked = watch('consent');

  // Format phone number live as user types: (XXX) XXX-XXXX
  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const raw = e.target.value.replace(/\D/g, '');
    let formatted = raw;

    if (raw.length > 0) {
      if (raw.length <= 3) {
        formatted = `(${raw}`;
      } else if (raw.length <= 6) {
        formatted = `(${raw.slice(0, 3)}) ${raw.slice(3)}`;
      } else {
        formatted = `(${raw.slice(0, 3)}) ${raw.slice(3, 6)}-${raw.slice(6, 10)}`;
      }
    }

    setValue('phone', formatted, { shouldValidate: true });
  };

  const onSubmit = (data: LeadContactFormData) => {
    saveContactAndProceed(data);
  };

  return (
    <div className="w-full max-w-2xl mx-auto animate-fade-in-up">
      <div className="bg-white rounded-3xl border border-slate-200/90 shadow-sm p-6 sm:p-8 md:p-10">
        {/* Header */}
        <div className="text-center sm:text-left mb-6 sm:mb-8">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-700 text-xs font-semibold mb-3">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Preliminary Qualification Assessment Complete</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
            Where Should We Send Your Results?
          </h1>
          <p className="mt-2 text-sm sm:text-base text-slate-600">
            Please enter your accurate contact information to receive your qualification breakdown and speak with a specialist.
          </p>
        </div>

        {/* Contact Form */}
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-5" noValidate>
          {/* First & Last Name */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="firstName" className="block text-sm font-semibold text-slate-700 mb-1.5">
                First Name <span className="text-rose-500">*</span>
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                  <User className="w-4 h-4" />
                </div>
                <input
                  id="firstName"
                  type="text"
                  placeholder="e.g. John"
                  autoComplete="given-name"
                  {...register('firstName')}
                  className={`w-full pl-10 pr-4 py-3 text-base rounded-xl border-2 transition-colors focus:outline-none focus:ring-2 focus:ring-sky-500/20 bg-white ${
                    errors.firstName
                      ? 'border-rose-300 bg-rose-50/30 focus:border-rose-500'
                      : 'border-slate-200 focus:border-sky-600'
                  }`}
                />
              </div>
              {errors.firstName && (
                <p className="mt-1.5 text-xs font-medium text-rose-600" role="alert">
                  {errors.firstName.message}
                </p>
              )}
            </div>

            <div>
              <label htmlFor="lastName" className="block text-sm font-semibold text-slate-700 mb-1.5">
                Last Name <span className="text-rose-500">*</span>
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                  <User className="w-4 h-4" />
                </div>
                <input
                  id="lastName"
                  type="text"
                  placeholder="e.g. Smith"
                  autoComplete="family-name"
                  {...register('lastName')}
                  className={`w-full pl-10 pr-4 py-3 text-base rounded-xl border-2 transition-colors focus:outline-none focus:ring-2 focus:ring-sky-500/20 bg-white ${
                    errors.lastName
                      ? 'border-rose-300 bg-rose-50/30 focus:border-rose-500'
                      : 'border-slate-200 focus:border-sky-600'
                  }`}
                />
              </div>
              {errors.lastName && (
                <p className="mt-1.5 text-xs font-medium text-rose-600" role="alert">
                  {errors.lastName.message}
                </p>
              )}
            </div>
          </div>

          {/* Email Address */}
          <div>
            <label htmlFor="email" className="block text-sm font-semibold text-slate-700 mb-1.5">
              Email Address <span className="text-rose-500">*</span>
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                <Mail className="w-4 h-4" />
              </div>
              <input
                id="email"
                type="email"
                placeholder="name@example.com"
                autoComplete="email"
                {...register('email')}
                className={`w-full pl-10 pr-4 py-3 text-base rounded-xl border-2 transition-colors focus:outline-none focus:ring-2 focus:ring-sky-500/20 bg-white ${
                  errors.email
                    ? 'border-rose-300 bg-rose-50/30 focus:border-rose-500'
                    : 'border-slate-200 focus:border-sky-600'
                }`}
              />
            </div>
            {errors.email && (
              <p className="mt-1.5 text-xs font-medium text-rose-600" role="alert">
                {errors.email.message}
              </p>
            )}
          </div>

          {/* Phone Number & Zip Code */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="phone" className="block text-sm font-semibold text-slate-700 mb-1.5">
                Phone Number <span className="text-rose-500">*</span>
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                  <Phone className="w-4 h-4" />
                </div>
                <input
                  id="phone"
                  type="tel"
                  placeholder="(555) 000-0000"
                  autoComplete="tel"
                  {...register('phone')}
                  onChange={handlePhoneChange}
                  className={`w-full pl-10 pr-4 py-3 text-base rounded-xl border-2 transition-colors focus:outline-none focus:ring-2 focus:ring-sky-500/20 bg-white ${
                    errors.phone
                      ? 'border-rose-300 bg-rose-50/30 focus:border-rose-500'
                      : 'border-slate-200 focus:border-sky-600'
                  }`}
                />
              </div>
              {errors.phone && (
                <p className="mt-1.5 text-xs font-medium text-rose-600" role="alert">
                  {errors.phone.message}
                </p>
              )}
            </div>

            <div>
              <label htmlFor="zipCode" className="block text-sm font-semibold text-slate-700 mb-1.5">
                ZIP Code <span className="text-rose-500">*</span>
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                  <MapPin className="w-4 h-4" />
                </div>
                <input
                  id="zipCode"
                  type="text"
                  maxLength={5}
                  placeholder="90210"
                  autoComplete="postal-code"
                  {...register('zipCode')}
                  className={`w-full pl-10 pr-4 py-3 text-base rounded-xl border-2 transition-colors focus:outline-none focus:ring-2 focus:ring-sky-500/20 bg-white ${
                    errors.zipCode
                      ? 'border-rose-300 bg-rose-50/30 focus:border-rose-500'
                      : 'border-slate-200 focus:border-sky-600'
                  }`}
                />
              </div>
              {errors.zipCode && (
                <p className="mt-1.5 text-xs font-medium text-rose-600" role="alert">
                  {errors.zipCode.message}
                </p>
              )}
            </div>
          </div>

          {/* Consent / TCPA Checkbox */}
          <div className="pt-2">
            <label className="flex items-start gap-3 cursor-pointer group">
              <input
                type="checkbox"
                id="consent"
                {...register('consent')}
                className="sr-only"
              />
              <div className="shrink-0 mt-0.5 text-sky-600">
                {consentChecked ? (
                  <CheckSquare className="w-5 h-5 fill-sky-100" />
                ) : (
                  <Square className="w-5 h-5 text-slate-400 group-hover:text-slate-600" />
                )}
              </div>
              <span className="text-xs text-slate-500 leading-relaxed select-none">
                I agree to the <a href="#terms" className="underline hover:text-slate-700">Terms of Service</a> & <a href="#privacy" className="underline hover:text-slate-700">Privacy Policy</a> and provide written authorization for BenefitPath and its network of licensed specialists to contact me regarding my eligibility inquiry at the phone number provided via calls, automated dialing, and SMS.
              </span>
            </label>
            {errors.consent && (
              <p className="mt-1.5 text-xs font-medium text-rose-600" role="alert">
                {errors.consent.message}
              </p>
            )}
          </div>

          {/* Action Button */}
          <div className="pt-4">
            <Button
              type="submit"
              size="lg"
              fullWidth
              isLoading={isSubmitting}
              rightIcon={<ArrowRight className="w-5 h-5" />}
            >
              Continue to Review
            </Button>
          </div>

          {/* Security Assurance */}
          <div className="pt-2 flex items-center justify-center gap-2 text-xs text-slate-500">
            <Lock className="w-3.5 h-3.5 text-emerald-600" />
            <span>256-Bit SSL Encrypted &bull; No Spam Guarantee</span>
          </div>
        </form>
      </div>
    </div>
  );
};
